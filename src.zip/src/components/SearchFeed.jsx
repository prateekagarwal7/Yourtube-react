import React, { useState } from 'react'
import { useEffect } from 'react'
import { Box,Typography } from '@mui/material'
import Video from './Video'

import { useParams } from 'react-router-dom'

//import { fetchFromAPI } from '../utils/fetchFromAPI'

import { fetchFromAPI } from '../utils/fetchFromAPI'

const SearchFeed = () => {



const [videos,setVideos] = useState([])
const {searchTerm}  = useParams();


useEffect (()=>{
  fetchFromAPI(`search?part=snippet&q=${searchTerm}`).then((data)=>setVideos(data.items))
},[searchTerm])
//userffect is a life cycle hook that is called when the component is initaly called



  return (
<Box p={2} sx={{overflow:'auto',height:'90vh'  , flex:2}}>
  <Typography variant='h4'fontWeight='bold' mb ={2} sx={{color
  :'white'}} >
    
   Search Result for: <span style={{color:"#F31503"}}>{searchTerm}

    </span>videos
  </Typography>
  <Video videos = {videos}></Video>

</Box>

    )
}

export default SearchFeed
